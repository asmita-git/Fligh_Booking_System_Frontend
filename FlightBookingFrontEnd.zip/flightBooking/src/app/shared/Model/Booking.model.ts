export class Booking {
  FBS_Reference_Id !: number;
    FBS_Flight_Id !: number;
    Cust_First_Name !: string;
    Cust_Last_Name!: string;
    Cust_EmailId !: string;
    Cust_Contact_No !: number;
}